# 旅遊瀏覽器（Android/Kotlin）

這是以 Android System WebView 為核心的可建置 Android Studio 專案。此執行環境只有 Java 21，沒有安裝 Android SDK、Android Studio 或 Gradle，因此本次無法在這裡實際編譯或驗證 APK；請在 Android Studio 中建置。

## 開發設定
- Kotlin + Android Gradle Plugin
- `minSdk = 26`（Android 8.0）；`compileSdk/targetSdk = 36`
- 瀏覽核心：Android System WebView，由裝置上的 Android System WebView／Chrome 更新提供核心更新。
- 無帳號、無開發者伺服器、無遙測、無自訂網址黑名單。

## 使用 Android Studio 建置
1. 在電腦安裝最新版 Android Studio，並於 SDK Manager 安裝 Android SDK Platform 36、Android SDK Build-Tools 及 Platform-Tools。
2. 解壓 `TravelBrowser.zip`，在 Android Studio 選擇 **Open**，開啟 `TravelBrowser` 資料夾。
3. 使用 JDK 17 或 Android Studio 內建 JDK，等待 Gradle Sync 完成。
4. 選單 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
5. Debug APK 預期輸出於 `app/build/outputs/apk/debug/app-debug.apk`。將 APK 傳到手機並允許該來源安裝應用程式後安裝。

亦可在已配置 Android SDK、Gradle 可用的環境中執行：

```bash
gradle assembleDebug
```

若沒有系統 Gradle，建議透過 Android Studio 的 Gradle Sync/Build 功能建置；此 ZIP 未包含 Gradle Wrapper JAR。

## 已實作的基礎功能
- 網址列、網址直開／一般文字搜尋、首頁與快捷連結
- 前進、後退、首頁、重新載入（網頁載入時系統 WebView 提供）
- 多分頁基本新增、切換與關閉
- 本機瀏覽紀錄、書籤
- Android DownloadManager 下載、分享、網頁文字搜尋
- 桌面版 User-Agent 切換、深色模式、首頁與搜尋模板設定
- 清除 WebView 快取、Cookie、表單資料與瀏覽紀錄
- 主要框架的 DNS、連線、逾時、TLS 錯誤提示
- HTTPS 憑證錯誤一律取消連線，不忽略憑證錯誤

## 重要安全與相容性說明
- WebView 的 JavaScript 為一般網站相容性而開啟，但沒有向網站暴露原生 JavaScript 介面；本機檔案存取關閉，混合內容採禁止模式，Safe Browsing 開啟。
- 輸入已有 scheme 的網址會原樣交給 WebView；無 scheme 且像網域的輸入會補上 `https://`，一般文字才送往設定的搜尋模板。HTTP 網址可使用，但可能不安全，介面會標示非加密連線。
- `WebViewClient` 不自行攔截網域；正常 HTTP 重新導向由 WebView 處理。網路層封鎖、DNS 污染、ISP 限制或地區限制不在應用程式可保證的範圍內。
- Android System WebView 的可用版本與相容性取決於裝置、系統版本、Play 商店／OEM 更新政策及使用者是否更新 WebView。中國大陸裝置的 WebView 供應情況可能不同。
- 目前是可供開發與測試的初始版本，並非已完成商業級安全審計。請在多個 Android 版本與不同品牌真機上測試後再廣泛分發。
- `usesCleartextTraffic=true` 是為了允許使用者明確輸入 HTTP 網址；應用程式不會把 HTTPS 自動降級為 HTTP。公共 Wi-Fi 上優先使用 HTTPS。

## 測試建議
1. 測試 `https://example.com`、明確的 `http://example.com`、一般搜尋詞及含路徑／查詢參數的完整網址。
2. 測試正常 301/302 重新導向，確認瀏覽器跟隨網站伺服器的重新導向。
3. 測試不存在的網域、關閉 Wi-Fi／行動網路、連線逾時及過期／錯誤 TLS 憑證網站；憑證錯誤必須取消。
4. 測試下載、Cookie 登入、書籤、清除資料、深色模式及多分頁記憶體消耗。
5. 在 Android 8、Android 10、Android 13、Android 15/16 等可用裝置或模擬器上測試；特別檢查 OEM WebView 提供者與更新狀態。
