package com.travel.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : android.app.Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var pageTitle: TextView
    private lateinit var content: LinearLayout
    private lateinit var tabCount: TextView
    private val tabs = mutableListOf<WebView>()
    private var activeIndex = 0
    private var darkMode = false
    private var desktopMode = false
    private var homeUrl = "https://www.baidu.com/"
    private var searchTemplate = "https://www.baidu.com/s?wd=%s"
    private val prefs by lazy { getSharedPreferences("browser_prefs", MODE_PRIVATE) }
    private val history = mutableListOf<Pair<String, String>>()
    private val bookmarks = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        homeUrl = prefs.getString("home", homeUrl) ?: homeUrl
        searchTemplate = prefs.getString("search", searchTemplate) ?: searchTemplate
        darkMode = prefs.getBoolean("dark", false)
        loadLists()
        buildUi()
        addTab(homeUrl)
    }

    private fun loadLists() {
        readPairs("history").forEach { history.add(it) }
        readPairs("bookmarks").forEach { bookmarks.add(it) }
    }
    private fun readPairs(key: String): List<Pair<String, String>> = try {
        val arr = JSONArray(prefs.getString(key, "[]"))
        (0 until arr.length()).map { val o = arr.getJSONObject(it); o.optString("title") to o.optString("url") }
    } catch (_: Exception) { emptyList() }
    private fun savePairs(key: String, list: List<Pair<String, String>>) {
        val arr = JSONArray()
        list.take(500).forEach { (title, url) -> arr.put(JSONObject().put("title", title).put("url", url)) }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg()) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8, 6, 8, 4) }
        address = EditText(this).apply {
            hint = "輸入網址或搜尋內容"; singleLine = true; textSize = 15f
            setTextColor(fg()); setHintTextColor(if (darkMode) 0xFFAAAAAA.toInt() else 0xFF777777.toInt())
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(if (darkMode) 0xFF292929.toInt() else 0xFFF0F2F5.toInt())
            setPadding(14, 2, 10, 2)
            setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) { navigateFromAddress(); true } else false }
        }
        top.addView(address, LinearLayout.LayoutParams(0, 46, 1f))
        top.addView(button("前往") { navigateFromAddress() })
        root.addView(top)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }
        root.addView(progress, LinearLayout.LayoutParams(-1, 3))
        pageTitle = TextView(this).apply { textSize = 12f; setPadding(12, 4, 12, 4); setTextColor(fg()); text = "準備就緒" }
        root.addView(pageTitle)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        root.addView(content)
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(2, 5, 2, 5); setBackgroundColor(if (darkMode) 0xFF202020.toInt() else 0xFFF7F7F7.toInt()) }
        listOf(
            "返回" to { goBack() }, "前進" to { goForward() }, "首頁" to { goHome() },
            "分頁" to { showTabs() }, "更多" to { showMore() }
        ).forEach { (label, action) ->
            val b = button(label, action)
            bar.addView(b, LinearLayout.LayoutParams(0, 44, 1f))
        }
        root.addView(bar)
        setContentView(root)
        applyTheme()
    }

    private fun bg() = if (darkMode) 0xFF151515.toInt() else Color.WHITE
    private fun fg() = if (darkMode) Color.WHITE else Color.BLACK
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setPadding(4, 0, 4, 0); setOnClickListener { action() }
    }
    private fun applyTheme() {
        root.setBackgroundColor(bg()); address.setTextColor(fg()); pageTitle.setTextColor(fg())
        tabs.forEach { it.setBackgroundColor(bg()) }
        window.statusBarColor = if (darkMode) 0xFF151515.toInt() else Color.WHITE
        window.navigationBarColor = if (darkMode) 0xFF151515.toInt() else Color.WHITE
        window.decorView.systemUiVisibility = if (darkMode) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWebView(): WebView = WebView(this).apply {
        setBackgroundColor(bg())
        settings.javaScriptEnabled = true // Standard browser compatibility; no privileged JS bridge is exposed.
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.safeBrowsingEnabled = true
        settings.userAgentString = WebSettings.getDefaultUserAgent(this@MainActivity)
        if (desktopMode) settings.userAgentString = settings.userAgentString.replace(" Mobile", "").replace(" Android", " X11; Linux x86_64")
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (view == currentWeb()) { address.setText(url); pageTitle.text = "載入中…"; progress.visibility = View.VISIBLE }
            }
            override fun onPageFinished(view: WebView, url: String) {
                if (view == currentWeb()) {
                    address.setText(url); pageTitle.text = view.title ?: url; progress.visibility = View.GONE
                    if (url.startsWith("http://", true)) pageTitle.text = "⚠ 非加密連線 · ${view.title ?: url}"
                    addHistory(view.title ?: url, url)
                }
            }
            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.cancel()
                if (view == currentWeb()) showError("HTTPS 憑證驗證失敗。為保護你的資料，瀏覽器已取消連線。請檢查日期、網路或網站憑證。")
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame && view == currentWeb()) {
                    val reason = when (error.errorCode) {
                        ERROR_HOST_LOOKUP -> "DNS 解析失敗，找不到網站主機。"
                        ERROR_CONNECT, ERROR_TIMEOUT -> "連線失敗或逾時。"
                        ERROR_INTERNET_DISCONNECTED -> "目前沒有網路連線。"
                        ERROR_FAILED_SSL_HANDSHAKE -> "TLS/HTTPS 安全連線協商失敗。"
                        else -> "網頁載入失敗：${error.description}（${error.errorCode}）"
                    }
                    showError(reason)
                }
            }
        }
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) { if (view == currentWeb()) progress.progress = newProgress }
            override fun onReceivedTitle(view: WebView, title: String?) { if (view == currentWeb() && !title.isNullOrBlank()) pageTitle.text = title }
        }
        setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    .setDescription("由旅遊瀏覽器下載")
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                manager.enqueue(request)
                Toast.makeText(this@MainActivity, "已加入下載管理", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "無法開始下載：${e.message}", Toast.LENGTH_LONG).show() }
        })
    }

    private fun currentWeb(): WebView? = tabs.getOrNull(activeIndex)
    private fun addTab(url: String? = null) {
        val web = makeWebView(); tabs.add(web); activeIndex = tabs.lastIndex
        content.removeAllViews(); content.addView(web, ViewGroup.LayoutParams(-1, -1))
        tabCountOrTitle(); if (url != null) web.loadUrl(url) else showHomePage()
    }
    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        activeIndex = index; content.removeAllViews(); content.addView(tabs[index], ViewGroup.LayoutParams(-1, -1))
        address.setText(tabs[index].url ?: ""); pageTitle.text = tabs[index].title ?: "分頁"; tabCountOrTitle()
    }
    private fun tabCountOrTitle() { title = "旅遊瀏覽器 (${tabs.size})" }
    private fun navigateFromAddress() {
        val raw = address.text.toString().trim(); if (raw.isEmpty()) return
        val url = resolveInput(raw)
        hideKeyboard()
        currentWeb()?.loadUrl(url) ?: addTab(url)
    }
    private fun resolveInput(input: String): String {
        val candidate = input.trim()
        val hasScheme = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(candidate)
        val looksLikeHost = candidate.contains('.') && !candidate.contains(' ') && !candidate.startsWith('.')
        if (hasScheme) return candidate // Do not rewrite user-provided schemes or destinations.
        if (looksLikeHost && !candidate.contains("\\")) return "https://$candidate"
        return searchTemplate.replace("%s", Uri.encode(candidate))
    }
    private fun hideKeyboard() { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0); address.clearFocus() }
    private fun goBack() { val w = currentWeb(); if (w?.canGoBack() == true) w.goBack() else Toast.makeText(this, "沒有可返回的頁面", Toast.LENGTH_SHORT).show() }
    private fun goForward() { val w = currentWeb(); if (w?.canGoForward() == true) w.goForward() else Toast.makeText(this, "沒有可前進的頁面", Toast.LENGTH_SHORT).show() }
    private fun goHome() { currentWeb()?.loadUrl(homeUrl) ?: addTab(homeUrl) }
    private fun showError(message: String) {
        pageTitle.text = "載入失敗"
        val html = """<html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:sans-serif;padding:24px;background:${if (darkMode) "#151515;color:white" else "white;color:#222"}'><h2>無法開啟網頁</h2><p>${escapeHtml(message)}</p><p>瀏覽器沒有封鎖或替換此網址。請檢查網路、DNS、網站狀態或地區網路限制。</p><button onclick='location.reload()'>重新載入</button></body></html>"""
        currentWeb()?.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }
    private fun escapeHtml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun addHistory(title: String, url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        if (history.firstOrNull()?.second == url) return
        history.add(0, title to url); if (history.size > 500) history.removeAt(history.lastIndex); savePairs("history", history)
    }
    private fun showHomePage() {
        val shortcuts = listOf("百度" to "https://www.baidu.com/", "Google" to "https://www.google.com/", "地圖" to "https://maps.google.com/", "維基百科" to "https://www.wikipedia.org/")
        val html = buildString {
            append("<html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:sans-serif;text-align:center;padding:24px;background:${if (darkMode) "#151515;color:white" else "#fff;color:#222"}'><h2>旅遊瀏覽器</h2><p>輸入網址或搜尋內容即可開始</p><div style='display:flex;flex-wrap:wrap;justify-content:center;gap:12px'>")
            shortcuts.forEach { (label, url) -> append("<a style='padding:16px;border-radius:12px;background:${if (darkMode) "#292929" else "#f0f2f5"};color:${if (darkMode) "white" else "#1769aa"};text-decoration:none' href='$url'>$label</a>") }
            append("</div><p style='margin-top:32px'>你的瀏覽紀錄與書籤保存在此裝置。</p></body></html>")
        }
        currentWeb()?.loadDataWithBaseURL("https://local.home/", html, "text/html", "UTF-8", null)
    }
    private fun showTabs() {
        val labels = tabs.mapIndexed { i, w -> "${i + 1}. ${w.title ?: w.url ?: "新分頁"}" }.toMutableList()
        labels.add("＋ 新分頁")
        AlertDialog.Builder(this).setTitle("分頁（${tabs.size}）").setItems(labels.toTypedArray()) { _, which ->
            if (which == tabs.size) addTab() else switchTab(which)
        }.setNeutralButton("關閉目前分頁") { _, _ -> closeCurrentTab() }.setNegativeButton("取消", null).show()
    }
    private fun closeCurrentTab() {
        if (tabs.size <= 1) { currentWeb()?.loadUrl(homeUrl); return }
        tabs.removeAt(activeIndex).apply { stopLoading(); destroy() }
        activeIndex = (activeIndex - 1).coerceAtLeast(0); switchTab(activeIndex)
    }
    private fun showMore() {
        val items = arrayOf("首頁", "新增分頁", "加入書籤", "書籤管理", "瀏覽紀錄", "下載管理", "搜尋網頁文字", "桌面版網站：${if (desktopMode) "開啟中" else "關閉"}", "深色模式：${if (darkMode) "開啟中" else "關閉"}", "設定", "清除瀏覽資料", "分享目前網頁")
        AlertDialog.Builder(this).setTitle("更多功能").setItems(items) { _, which -> when (which) {
            0 -> goHome(); 1 -> addTab(); 2 -> addBookmark(); 3 -> showSavedList("書籤", bookmarks, true); 4 -> showSavedList("瀏覽紀錄", history, false)
            5 -> openDownloads(); 6 -> findText(); 7 -> { desktopMode = !desktopMode; reloadWithMode() }
            8 -> { darkMode = !darkMode; prefs.edit().putBoolean("dark", darkMode).apply(); applyTheme(); Toast.makeText(this, "已切換主題；部分網頁需重新載入", Toast.LENGTH_SHORT).show() }
            9 -> showSettings(); 10 -> clearData(); 11 -> sharePage()
        } }.show()
    }
    private fun addBookmark() {
        val w = currentWeb() ?: return; val url = w.url ?: return
        if (bookmarks.none { it.second == url }) { bookmarks.add(0, (w.title ?: url) to url); savePairs("bookmarks", bookmarks) }
        Toast.makeText(this, "已加入書籤", Toast.LENGTH_SHORT).show()
    }
    private fun showSavedList(title: String, list: MutableList<Pair<String, String>>, isBookmark: Boolean) {
        if (list.isEmpty()) { Toast.makeText(this, "目前沒有內容", Toast.LENGTH_SHORT).show(); return }
        val names = list.map { "${it.first}\n${it.second}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle(title).setItems(names) { _, which -> currentWeb()?.loadUrl(list[which].second) }.setNeutralButton("清空") { _, _ ->
            list.clear(); savePairs(if (isBookmark) "bookmarks" else "history", list); Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("取消", null).show()
    }
    private fun showSettings() {
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 8, 22, 0) }
        val home = EditText(this).apply { hint = "首頁網址"; setText(homeUrl); singleLine = true }
        val search = EditText(this).apply { hint = "搜尋網址模板，搜尋詞用 %s"; setText(searchTemplate); singleLine = true }
        fields.addView(TextView(this).apply { text = "首頁網址" }); fields.addView(home)
        fields.addView(TextView(this).apply { text = "搜尋網址模板（例如 https://www.google.com/search?q=%s）" }); fields.addView(search)
        AlertDialog.Builder(this).setTitle("設定").setView(fields).setPositiveButton("儲存") { _, _ ->
            val h = home.text.toString().trim(); val s = search.text.toString().trim()
            if (h.startsWith("https://") || h.startsWith("http://")) homeUrl = h
            if ((s.startsWith("https://") || s.startsWith("http://")) && s.contains("%s")) searchTemplate = s
            prefs.edit().putString("home", homeUrl).putString("search", searchTemplate).apply()
            Toast.makeText(this, "設定已儲存", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("取消", null).show()
    }
    private fun clearData() {
        AlertDialog.Builder(this).setTitle("清除瀏覽資料").setMessage("清除所有分頁的快取、Cookie、瀏覽紀錄與表單資料？書籤會保留。")
            .setPositiveButton("清除") { _, _ ->
                tabs.forEach { it.clearCache(true); it.clearFormData(); it.clearHistory() }
                CookieManager.getInstance().removeAllCookies { }
                CookieManager.getInstance().flush()
                history.clear(); savePairs("history", history)
                Toast.makeText(this, "瀏覽資料已清除", Toast.LENGTH_LONG).show()
            }.setNegativeButton("取消", null).show()
    }
    private fun findText() {
        val input = EditText(this).apply { hint = "要尋找的文字" }
        AlertDialog.Builder(this).setTitle("搜尋網頁文字").setView(input).setPositiveButton("搜尋") { _, _ ->
            currentWeb()?.findAllAsync(input.text.toString())
            currentWeb()?.setFindListener { active, total, _ -> Toast.makeText(this, if (total == 0) "找不到文字" else "符合 $active / $total 處", Toast.LENGTH_SHORT).show() }
        }.setNegativeButton("取消", null).show()
    }
    private fun reloadWithMode() {
        tabs.forEach { it.settings.userAgentString = if (desktopMode) "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari" else WebSettings.getDefaultUserAgent(this) }
        currentWeb()?.reload()
    }
    private fun openDownloads() {
        try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
        catch (_: Exception) { Toast.makeText(this, "請在系統的「下載」應用中查看檔案", Toast.LENGTH_LONG).show() }
    }
    private fun sharePage() {
        val w = currentWeb() ?: return
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, w.url ?: "") }
        startActivity(Intent.createChooser(intent, "分享網頁"))
    }
    override fun onBackPressed() { if (currentWeb()?.canGoBack() == true) goBack() else super.onBackPressed() }
    override fun onDestroy() { tabs.forEach { it.stopLoading(); it.destroy() }; tabs.clear(); super.onDestroy() }
}
